## 23 may 2024

remenber --clock option for bag

whichever mapping software lib you prefer, (pls no cartographer)
 

for map: (task1)
- odometry -> tf
- mapping node (slam node)
- rviz w

for nav inside map:
put corrrect size of robot
from rviz receive goals and move in the map gen in task 1

gymansium inverted pole
deadline: 23/07/2024

https://drive.google.com/drive/folders/1W36wPi0H7kA7qYGiOfbyR5ikBASlyCpZ